package com.example.resultapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
TextView mssg,result,mssg1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
            mssg=findViewById(R.id.sem);
            result=findViewById(R.id.cgpa);
            mssg1=findViewById(R.id.congo);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.resultmenu,menu);
            return true;
    }
    //@Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case R.id.subitem1:

                mssg.setText("Your First Semester Result is ");
                result.setText("CGPA : 9.13");
                mssg1.setText("Congratulations !!!!");
                return true;
            case R.id.subitem2:
                mssg.setText("Your Second Semester Result is ");
                result.setText("CGPA : 9.08");
                mssg1.setText("Congratulations !!!!");
                return true;
            case R.id.subitem3:
                mssg.setText("Your Third Semester Result is ");
                result.setText("CGPA : 8.45");
                mssg1.setText("Congratulations !!!!");
                return true;
            case R.id.subitem4:
                mssg.setText("Your Fourth Semester Result is ");
                result.setText("CGPA : 8.51");
                mssg1.setText("Congratulations !!!!");
                return true;
            case R.id.subitem5:
                mssg.setText("Your Fifth Semester Result is ");
                result.setText("CGPA : 8.52");
                mssg1.setText("Congratulations !!!!");
                return true;
            case R.id.subitem6:
                mssg.setText("Your Sixth Semester Result is ");
                result.setText("CGPA : 8.53");
                mssg1.setText("Congratulations !!!!");
                return true;
            case R.id.subitem7:
                mssg.setText("Your Seventh Semester Result is ");
                result.setText("CGPA : 8.88");
                mssg1.setText("Congratulations !!!!");
                return true;
            case R.id.subitem8:
                mssg.setText("Your Eighth Semester Result is ");
                result.setText("CGPA : 8.89");
                mssg1.setText("Congratulations !!!!");
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }
}